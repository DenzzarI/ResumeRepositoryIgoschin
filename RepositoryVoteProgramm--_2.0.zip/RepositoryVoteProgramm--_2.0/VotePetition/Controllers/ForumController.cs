﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using VotePetition.Interfaces;
using VotePetition.Models;
using Microsoft.Data.SqlClient;
using System.Data;
using VotePetition.ViewModel;

namespace VotePetition.Controllers 
{
    public class ForumController : Controller
    {
        private readonly IAllPetition allPetition;
        private IUser user;
        private AppDBContent _context;
        private IForum forum;
        private IPetitionForum petitionForum;
        public ForumController(IAllPetition iallPetition, AppDBContent context, IForum _forum, IPetitionForum _petitionForum, IUser _user)
        {
            allPetition = iallPetition;
            _context = context;
            forum = _forum;
            petitionForum = _petitionForum;
            user = _user;
        }
        public IActionResult NewsBlog()
        {
            return View();
        }
        public IActionResult listCommentsNull(int id)
        {
            Petition pet = allPetition.getObjectPetition(id);
            ViewBag.title = pet.title;
            ViewBag.text = pet.text;
            ViewBag.idPetition = pet.PetitionId;
            return View();
        }
        
        [HttpPost]
        public IActionResult CreateCommentar(int id,IndexViewModelForum com)
        {
            User us = user.getObjectUser(User.Identity.Name);
            Forum fr = new Forum();
            fr.title = com.comment.title;
            fr.text = com.comment.text;
            fr.UserId = (int)us.UserId;
            _context.Forum.Add(fr);
            _context.SaveChanges();
            PetitionForum fp = new PetitionForum();
            fp.PetitionId = id;
            Forum f1 = forum.lastCommentId();
            fp.ForumId = f1.ForumId;
            _context.petitionForum.Add(fp);
            _context.SaveChanges();
            return RedirectToAction("listPetitions", "Petitions");

        }
        [HttpGet]
        public IActionResult listComments(int id)
        {
            Petition pet = allPetition.getObjectPetition(id);
            ViewBag.title = pet.title;
            ViewBag.text = pet.text;
            ViewBag.idPetition = pet.PetitionId;
            /*----------------------------------------------*/
            //IEnumerable<Forum> f = forum.allCommentsById(id);
            IEnumerable<PetitionForum> f1 = petitionForum.GetPetitionForumsbyIdPetition(id);//Получаю все записи где ID
                                                                                            //петиции равно той которая выбрана
            IEnumerable<Forum> f2 = forum.allComments();//Все коментарии
            List<PetitionForum> listForum = new List<PetitionForum>();
            List<Forum> Forum = new List<Forum>();
            List<Forum> FinalForum = new List<Forum>();
            listForum = f1.ToList();
            Forum = f2.ToList();
            bool yes = false;
            for (int i = 0; i < Forum.Count(); i++)
            {
                for(int j = 0;j < listForum.Count();j++)
                {
                        if (listForum[j].ForumId == Forum[i].ForumId)
                        {
                            FinalForum.Add(Forum[i]);
                            yes = true;
                        }
                }
                   
            }
            IndexViewModelForum m = new IndexViewModelForum();
            m.forum = FinalForum;
            if(yes == true)
            {
                return View(m);
            }
            else
            {
                pet = allPetition.getObjectPetition(id);
                ViewBag.title = pet.title;
                ViewBag.text = pet.text;
                ViewBag.idPetition = pet.PetitionId;
                return RedirectToRoute("default", new { controller = "Forum", action = "listCommentsNull", id=pet.PetitionId});
                // return RedirectToAction("listCommentsNull", pet.PetitionId,"Forum");
            }
        }
    }
}

