﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Controllers
{
    public class PetitionsController : Controller
    {
        private readonly IAllPetition allPetition;
        private readonly IPetitionsCategory allCategory;
        private AppDBContent _context;
        private readonly IUser allUser;
        private IEnumerable<Petition> pet;
        private readonly IVote voteI;

        public PetitionsController(IAllPetition iallPetition,IPetitionsCategory ipetitionsCategory, IUser iUser, AppDBContent context, IVote vote)
        {
            allPetition = iallPetition;
            allCategory = ipetitionsCategory;
            allUser = iUser;
            _context = context;
            this.voteI = vote;
        }
        public ViewResult listPetitions()
        {
            var pet = allPetition.AllPetitions;
            return View(pet);
        }
        public ViewResult listPetitionsShow(int id)
        {
            if (id == 1)
                 pet = allPetition.AllPetitionsBySignature;
            else if(id == 2)
                 pet = allPetition.AllPetitionsByStatus;
            return View(pet);
        }
        [Authorize(Roles = "user")]
        [HttpGet]
        public IActionResult CreatePetition()
        {
            if (User.Identity.IsAuthenticated)
            {
                return View();
            }
            return RedirectToAction("ErrorLogin", "Home");
            //return Content("не аутентифицирован");
        }
        string[] splitDatastring(string text, string delimiter)
        {
            string[] result = text.Split(delimiter);

            return result;
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePetition(CrPetition model)
        {
            User user = allUser.getObjectUser(User.Identity.Name);
            Petition pt = new Petition();
            pt.UserId = (int)user.UserId;
            pt.Category = allCategory.getObjectCategory(1);
            if (model.img == null)
                pt.img = "LogoKharkiv.jpg";
            else
                pt.img = model.img;
            pt.colSignature = 0;
            pt.StatusId = 0;
            pt.title = model.title;
            pt.text = model.text;
            string date = DateTime.Now.ToString();
            string[] dates = splitDatastring(date, " ");
            pt.datePublication = dates[0];
            pt.timePublication = dates[1];

            _context.Petition.Add(pt);
            await _context.SaveChangesAsync();
            return RedirectToAction("listPetitions", "Petitions");
        }
        public ViewResult Petition(int id)
        {
            Petition pet = allPetition.AllPetitions
               .FirstOrDefault(g => g.PetitionId == id);
            User user = allUser.getObjectUser(pet.UserId);
            Category cat = allCategory.getObjectCategory(pet.Category.CategoryId);
            PetitionForShow petS = new PetitionForShow();
            if (pet.StatusId == 0)
                petS.Status = "Триває збір підписів";
            else if(pet.StatusId == 1)
                petS.Status = "На розгляданні";
            else
                petS.Status = "З відповіддю";
            petS.PetitionId = pet.PetitionId;
            petS.img = pet.img;
            petS.datePublication = pet.datePublication;
            petS.timePublication = pet.timePublication;
            petS.colSignature = pet.colSignature;
            petS.userName = user.surname+" "+user.name+" "+user.secondName;
            petS.category = cat.name;
            petS.text = pet.text;
            return View(petS);
        }

        public async Task<IActionResult> Vote(int id)
        {
            User user = allUser.getObjectUser(User.Identity.Name);
            Vote voteProv = voteI.getObjectVotebyUserId((int)user.UserId);
            if(voteProv == null)//если нет не одной записи с голосованием этого пользователя в БД
            {
                Vote vote = new Vote();
                string date = DateTime.Now.ToString();
                vote.UserId = (int)user.UserId;
                vote.PetitionId = id;
                vote.dateOfSign = date;
                _context.Vote.Add(vote);
                await _context.SaveChangesAsync();
            }else if(voteProv.UserId == user.UserId && voteProv.PetitionId == id)
            {
                return RedirectToAction("ErrorLogin", "Home");
            }
            else
            {
                Vote vote = new Vote();
                string date = DateTime.Now.ToString();
                vote.UserId = (int)user.UserId;
                vote.PetitionId = id;
                vote.dateOfSign = date;
                _context.Vote.Add(vote);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction("listPetitions", "Petitions");

        }
        public ViewResult ListUsersPetitions(int id)
        {
            IEnumerable<Vote> vote = voteI.AllVoteByIdPetition(id);//Получаем все записи с id петиции
            IEnumerable<userForShow> userForShows = allUser.FindAllUsers(vote);

            return View(userForShows);
        }

    }
}
