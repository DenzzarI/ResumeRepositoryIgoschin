﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;

namespace VotePetition.Controllers
{
    [Authorize(Roles= "admin")]
    public class AdministratorController : Controller
    {
        private AppDBContent _context;
        private readonly IUser user;
        private readonly IAllPetition allPetition;

        public AdministratorController(AppDBContent context, IUser _user, IAllPetition _allPetition)
        {
            _context = context;
            user = _user;
            allPetition = _allPetition;
        }
        public ViewResult ValidateUsers()
        {
            var users = user.allUsers;
            return View(users);
        }
    }
}
