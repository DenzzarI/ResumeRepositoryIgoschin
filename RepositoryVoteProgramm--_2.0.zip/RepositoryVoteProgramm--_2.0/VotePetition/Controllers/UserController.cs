﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;
using VotePetition.ViewModel;

namespace VotePetition.Controllers
{
    public class UserController : Controller
    {
        private readonly IUser user;
        private AppDBContent _context;
        public UserController(IUser _user, AppDBContent context)
        {
            _context = context;
            this.user = _user;
        }
        [HttpGet]
        public IActionResult Profile ()
        {
            if (User.Identity.IsAuthenticated)
            {
                var i = user.getObjectUser(User.Identity.Name);
                if(i == null)
                    return RedirectToAction("Login", "Account");
                else
                {
                    IVMUser iVMUserProfile = new IVMUser(i);
                    return View(iVMUserProfile);
                }
            }
            return RedirectToAction("ErrorLogin", "Home");
        }
        [HttpPost]
        public async Task<IActionResult> UpdateProfile(IVMUser model)
        {
                var us = user.getObjectUser(User.Identity.Name);

            us.name = model.updateModel.name;
            us.surname = model.updateModel.surname;
            us.secondName = model.updateModel.secondName;
            us.addres = model.updateModel.addres;
            us.number = model.updateModel.number;
            us.descProfile = model.updateModel.descProfile;
            us.email = model.updateModel.Email;
            //_context.User.Update(user1);
            await _context.SaveChangesAsync();
            IVMUser us1 = new IVMUser();
            us1.User = us;
            //return View(us1);
            return RedirectToAction("ErrorLogin", "Home");
        }
    }

}
