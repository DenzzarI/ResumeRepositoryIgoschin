﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private AppDBContent _context;
        private readonly IUser user;

        public HomeController(ILogger<HomeController> logger, AppDBContent context, IUser user)
        {
            _logger = logger;
            _context = context;
            this.user = user;
        }
        public IActionResult Index()
        {
          
                return View();
            
        }
        /*public IActionResult Index()
        {
            return View();
        }*/
        public IActionResult ErrorLogin()
        {
            return View();
        }
        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult Contact()
        {
            return View();
        }
        public IActionResult inf1()
        {
            return View();
        }
        public IActionResult AddInf()
        {
            return View();
        }
        public IActionResult KhaInfo()
        {
            return View();
        }
        public IActionResult AboutService()
        {
            return View();
        }
        public IActionResult _Layout1()
        {
            if (User.Identity.IsAuthenticated)
            {
                User us = user.getObjectUser(User.Identity.Name);
                return View(us);
            }
            return RedirectToAction("ErrorLogin", "Home");
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
