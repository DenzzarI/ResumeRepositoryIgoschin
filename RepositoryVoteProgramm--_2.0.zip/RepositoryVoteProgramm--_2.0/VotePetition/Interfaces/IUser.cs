﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Models;

namespace VotePetition.Interfaces
{
    public interface IUser
    {
        public IEnumerable<User> allUsers { get; }
        public User getObjectUser(string email);
        public User getObjectUser(int id);
        public IEnumerable<userForShow> FindAllUsers(IEnumerable<Vote> votes);
        public IEnumerable<User> allUserqquery { get; }
    }
}
