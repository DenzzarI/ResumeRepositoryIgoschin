﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Models;

namespace VotePetition.Interfaces
{
    public interface IForum
    {
        public IEnumerable<Forum> allComments();
        public IEnumerable<Forum> allCommentsById(int id);
        public Forum lastCommentId();
    }
}
