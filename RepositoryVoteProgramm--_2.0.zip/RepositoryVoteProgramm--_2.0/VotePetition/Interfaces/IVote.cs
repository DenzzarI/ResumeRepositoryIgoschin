﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Models;

namespace VotePetition.Interfaces
{
    public interface IVote
    {
        public IEnumerable<Vote> AllVote { get; }
        public IEnumerable<Vote> AllVoteByIdPetition(int id);
        public Vote getObjectVotebyUserId(int userId);
    }
}
