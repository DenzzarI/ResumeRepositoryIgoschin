﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Models;

namespace VotePetition.Interfaces
{
    public interface IAllPetition
    {
        IEnumerable<Petition> AllPetitions { get;}
        IEnumerable<Petition> AllPetitionsBySignature { get; }
        IEnumerable<Petition> AllPetitionsByStatus { get; }
        IEnumerable<Petition> AllPetitionsSort(int id);
        IEnumerable<Petition> GetPetitions { get;}
        Petition getObjectPetition(int petitionId);
    }
}
