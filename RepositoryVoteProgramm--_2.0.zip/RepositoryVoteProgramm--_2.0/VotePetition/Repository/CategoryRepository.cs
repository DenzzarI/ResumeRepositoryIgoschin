﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Repository
{
    public class CategoryRepository : IPetitionsCategory
    {
        private readonly AppDBContent appDBContent;
        public CategoryRepository(AppDBContent appDBContent)
        {
            this.appDBContent = appDBContent;
        }
        public IEnumerable<Category> AllCategories => appDBContent.Category;

        public Category getObjectCategory(int CategoryId)=> appDBContent.Category.FirstOrDefault(p => p.CategoryId == CategoryId);
    }
}
