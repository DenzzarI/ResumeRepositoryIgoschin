﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Repository
{
    
    public class PetitionForumRepository : IPetitionForum
    {
        private readonly AppDBContent appDBContent;

        public PetitionForumRepository(AppDBContent _appDBContent)
        {
            this.appDBContent = _appDBContent;
        }
        public IEnumerable<PetitionForum> GetPetitionForumsbyIdPetition(int idPetition)=>appDBContent.petitionForum.Where(c => c.PetitionId == idPetition);
    }
}
