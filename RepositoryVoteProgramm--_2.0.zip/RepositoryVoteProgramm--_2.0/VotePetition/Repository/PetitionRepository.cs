﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Repository
{
    public class PetitionRepository : IAllPetition
    {
        private readonly AppDBContent appDBContent;

        public PetitionRepository(AppDBContent appDBContent)
        {
            this.appDBContent = appDBContent;
        }
        public IEnumerable<Petition> AllPetitions => appDBContent.Petition.Include(c => c.Category);
        public IEnumerable<Petition> GetPetitions { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public IEnumerable<Petition> AllPetitionsBySignature => appDBContent.Petition.OrderByDescending(c =>c.colSignature);
        public IEnumerable<Petition> AllPetitionsByStatus => appDBContent.Petition.Where(c => c.StatusId == 1);
        public IEnumerable<Petition> AllPetitionsSort(int id) => appDBContent.Petition.Include(c => c.Category);
        public Petition getObjectPetition(int petitionId) => appDBContent.Petition.FirstOrDefault(p => p.PetitionId == petitionId);
    }
}
