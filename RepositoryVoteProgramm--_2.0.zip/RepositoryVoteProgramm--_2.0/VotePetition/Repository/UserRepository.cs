﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Repository
{
    public class UserRepository : IUser
    {
        private readonly AppDBContent appDBContent;

        public UserRepository(AppDBContent appDBContent)
        {
            this.appDBContent = appDBContent;
        }

        public IEnumerable<User> allUsers => appDBContent.User.Include(c => c.UserId);

        public IEnumerable<User> allUserqquery => throw new NotImplementedException();

        public IEnumerable<userForShow> FindAllUsers(IEnumerable<Vote> votes)=> (IEnumerable<userForShow>)appDBContent.User.Join(votes, // второй набор
             p => p.UserId, // свойство-селектор объекта из первого набора
             c => c.UserId, // свойство-селектор объекта из второго набора
             (p, c) => new { surname = p.surname, name = p.name, secondName = p.secondName, dateOfSign = c.dateOfSign }); // результат

        public User getObjectUser(string email)=>appDBContent.User.FirstOrDefault(p => p.email == email);

        public User getObjectUser(int id) => appDBContent.User.FirstOrDefault(p => p.UserId == id);
    }
}
