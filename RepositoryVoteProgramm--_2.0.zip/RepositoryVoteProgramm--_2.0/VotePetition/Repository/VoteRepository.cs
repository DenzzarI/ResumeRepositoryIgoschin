﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Repository
{
    public class VoteRepository : IVote
    {
        private readonly AppDBContent appDBContent;
        public VoteRepository(AppDBContent appDBContent)
        {
            this.appDBContent = appDBContent;
        }

        public IEnumerable<Vote> AllVote => appDBContent.Vote.Include(c => c.VoteId); //Petition.Include(c => c.Category);

        public IEnumerable<Vote> AllVoteByIdPetition(int id) => appDBContent.Vote.Include(p => p.PetitionId == id);

        public Vote getObjectVotebyUserId(int userId) => appDBContent.Vote.FirstOrDefault(p => p.UserId == userId);
    }

}
