﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Repository
{
    public class ForumRepository : IForum
    {
        private readonly AppDBContent appDBContent;
        public ForumRepository(AppDBContent appDBContent)
        {
            this.appDBContent = appDBContent;
        }

        public Forum lastCommentId() => appDBContent.Forum.OrderBy(c=>c.ForumId).Last();

        public IEnumerable<Forum> allComments() => appDBContent.Forum.Where(c => c.ForumId > 0);
        IEnumerable<Forum> IForum.allCommentsById(int id)=> appDBContent.Forum.Where(c => c.ForumId == 4);
    }
}
