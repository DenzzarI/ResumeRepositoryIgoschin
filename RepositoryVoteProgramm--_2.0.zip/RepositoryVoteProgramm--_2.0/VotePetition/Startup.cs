using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Mocks;
using VotePetition.Repository;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace VotePetition
{
    public class Startup
    {
        private IConfigurationRoot confString;
        public Startup(IHostEnvironment hostEnv)
        {
            confString = new ConfigurationBuilder().SetBasePath(hostEnv.ContentRootPath).AddJsonFile("dbsettings.json").Build();
        }
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        public object DBObjects { get; private set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<AppDBContent>(options => options.UseSqlServer(confString.GetConnectionString("DefaultConnection")));
            services.AddControllersWithViews();
            services.AddMvc();
            services.AddTransient<IAllPetition, PetitionRepository>();
            services.AddTransient<IPetitionsCategory, CategoryRepository>();
            services.AddTransient<IUser, UserRepository>();
            services.AddTransient<IVote, VoteRepository>();
            services.AddTransient<IForum, ForumRepository>();
            services.AddTransient<IPetitionForum, PetitionForumRepository>();
            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
                 .AddCookie(options =>
                 {
                     options.LoginPath = new Microsoft.AspNetCore.Http.PathString("/Account/Login");
                     options.AccessDeniedPath = new Microsoft.AspNetCore.Http.PathString("/Account/Login");
                 });
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddMemoryCache();
            services.AddSession();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            //C����� ������������� 
            app.UseRouting();
            //������������ � �����������
            app.UseStatusCodePages();
            app.UseSession();
            app.UseAuthentication();
            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute("default","{controller=Home}/{action=Index}/{id?}");
                endpoints.MapControllerRoute("Petition","{controller=Petitons}/{action=Show}/{id?}");
                endpoints.MapControllerRoute("Petition1", "{controller=Petitons}/{action=listPetitionsShow}/{type?}");
                endpoints.MapControllerRoute("listComments", "{controller=Forum}/{action=CreateCommentar}/{id?}");
                endpoints.MapControllerRoute("listCommentsNull", "{controller=Forum}/{action=listCommentsNull}/{id?}");
                endpoints.MapControllerRoute("User", "{controller=User}/{action=UpdateProfile}");
            });
           

        }
    }
 }
