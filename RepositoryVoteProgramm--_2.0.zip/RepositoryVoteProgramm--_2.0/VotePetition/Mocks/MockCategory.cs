﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Mocks
{
    public class MockCategory
    {

        public IEnumerable<Category> AllCategories
        {
            get
            {
                return new List<Category>
                {
                    new Category{name = "Благоустройство",description="Благоустройство домов и дворов"},
                    new Category{name = "Социальная защита",description="Социальная защита"}
                };
            }
        }
    }
}
