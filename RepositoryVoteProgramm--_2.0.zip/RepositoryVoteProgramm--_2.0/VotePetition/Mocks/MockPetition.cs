﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Interfaces;
using VotePetition.Models;

namespace VotePetition.Mocks
{
    public class MockPetition
    {
        //private readonly IPetitionsCategory petitionsCategory = new MockCategory();
        public IEnumerable<Petition> AllPetitions
        {
            get
            {
                return new List<Petition>
                {
                    new Petition{
                        PetitionId = 1,
                        title="Демонтаж пам'ятника Ватутіну",
                        text="Станом на сьогодні у Маріїнському парку, що розташований перед Верховної Радою України досі є пам'ятник одному з окупантів та україноненависників - Миколі Ватутіну. Проти цього пам'ятника було проведено десятки акцій різноманітними патріотичними організаціями. Нещодавно, невідомі облили його зеленкою. Микола Ватутін - особа, яка воювала з армією УНР, повстанцями Холодного Яру та бійцями УПА, дерибанила Польщу 1939 та сотнями тисяч відправляла українців на безглуздий забій.Враховуючи те, що під пам'ятником, ймовірно, може бути його могила, прошу провести рішення про цивілізований демонтаж пам'ятника та перенесення могили (якщо вона є) на територію одного з кладовищ міста Києва.",
                        datePublication="14.02.2020",
                        timePublication="16:06",
                        colSignature=10313,
                        img="/img/2.jpg",
                       // Category=petitionsCategory.AllCategories.First()
                    },
                    new Petition{
                        PetitionId = 2,
                        title="Укладка плитки у памятника",
                        text="Укладка плитки у памятника",
                        datePublication="12.04.22",
                        timePublication="12.06",
                        colSignature=1500,
                        img="/img/1.jpg",
                       // Category=petitionsCategory.AllCategories.First()
                    },
                    new Petition{
                        PetitionId = 3,
                        title="Укладка плитки у памятника",
                        text="Укладка плитки у памятника",
                        datePublication="12.04.22",
                        timePublication="12.06",
                        colSignature=6005,
                        img="/img/1.jpg",
                       // Category=petitionsCategory.AllCategories.First()
                    },
                    new Petition{
                        PetitionId = 3,
                        title="Укладка плитки у памятника",
                        text="Укладка плитки у памятника",
                        datePublication="12.04.22",
                        timePublication="12.06",
                        colSignature=6005,
                        img="/img/1.jpg",
                      //  Category=petitionsCategory.AllCategories.First()
                    }
                };
            }
            set { }
        }
        public IEnumerable<Petition> GetPetitions { get; set; }

        public Petition getObjectPetition(int petitionId)
        {
            throw new NotImplementedException();
        }
    }
}
