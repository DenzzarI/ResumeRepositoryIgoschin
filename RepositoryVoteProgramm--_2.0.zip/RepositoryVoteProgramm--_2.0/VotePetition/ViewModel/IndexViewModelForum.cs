﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Models;

namespace VotePetition.ViewModel
{
    public class IndexViewModelForum
    {
        public List<Forum> forum { get; set; }
        public Comment comment {get; set;}

       
    }
}
