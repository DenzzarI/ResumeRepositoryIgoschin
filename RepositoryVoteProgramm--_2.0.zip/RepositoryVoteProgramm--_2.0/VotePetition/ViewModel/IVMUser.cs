﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VotePetition.Models;

namespace VotePetition.ViewModel
{
    public class IVMUser
    {
        public User User { get; set; }
        public UpdateModel updateModel { get; set; }

        public IVMUser() { }
        public IVMUser(User user)
        {
            this.User = user;
        }
    }
}
