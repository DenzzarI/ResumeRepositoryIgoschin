﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class Confirm
    {
        [Key]
        public int ConfirmId;
        public bool confirmT;
        public List<ConfirmUser> confirmUser { get; set; }
    }
}
