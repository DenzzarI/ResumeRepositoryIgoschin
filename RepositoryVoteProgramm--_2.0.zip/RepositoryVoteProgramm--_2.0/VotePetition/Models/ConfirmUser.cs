﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    [Keyless]
    public class ConfirmUser
    {
        public int idUser;
        public int idConfirm;
        public Confirm confirm { get; set; }
        public User user { get; set; }
    }
}
