﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class PetitionForShow
    {
        public int PetitionId { get; set; }
        public string title { get; set; }
        public string text { get; set; }
        public string Status { get; set; }
        public string datePublication { get; set; }
        public string timePublication { get; set; }
        public int colSignature { get; set; }
        public string img { get; set; }
        public string category { get; set; }
        public string userName { get; set; }

        public PetitionForShow() { }
        public PetitionForShow(string text,string text1, string status,string datePublication, string timePublication, int colSignature, string img, string category, string userName)
        {
            this.title = title;
            this.text = text1;
            this.datePublication = datePublication;
            this.timePublication = timePublication;
            this.colSignature = colSignature;
            this.img = img;
            this.category = category;
            this.userName = userName;
        }
    }
}
