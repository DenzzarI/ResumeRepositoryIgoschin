﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class userForShow
    {
       public string name { get; set; }
        public string surname { get; set; }
        public string secondName { get; set; }
        public string dateOfSign { get; set; }
    }
}
