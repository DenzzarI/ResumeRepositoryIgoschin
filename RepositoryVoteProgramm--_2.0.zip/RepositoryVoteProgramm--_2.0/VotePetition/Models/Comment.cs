﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class Comment
    {
        [Required(ErrorMessage = "Не указана title")]
        public string title { get; set; }

        [Required(ErrorMessage = "Не указано основний текст коментаря")]
        public string text { get; set; }
    }
}
