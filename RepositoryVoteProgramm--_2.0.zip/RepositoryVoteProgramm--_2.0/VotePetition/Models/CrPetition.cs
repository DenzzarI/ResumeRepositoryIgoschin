﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class CrPetition
    {
        [Required(ErrorMessage = "Не указана назва петиції")]
        public string title { get; set; }

        [Required(ErrorMessage = "Не указано основний текст петиції")]
        public string text { get; set; }
        public string img { get; set; }
    }
}
