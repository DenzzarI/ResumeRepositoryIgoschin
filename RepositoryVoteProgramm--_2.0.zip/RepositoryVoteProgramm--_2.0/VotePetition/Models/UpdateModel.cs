﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class UpdateModel
    {
        [Required(ErrorMessage = "Не указан номер телефону")]
        public string number { get; set; }

        [Required(ErrorMessage = "Не указано Ім'я")]
        public string name { get; set; }

        [Required(ErrorMessage = "Не указано INN")]
        public string INN { get; set; }

        [Required(ErrorMessage = "Не указана адреса")]
        public string addres { get; set; }

        [Required(ErrorMessage = "Не указано прізаище")]
        public string surname { get; set; }


        [Required(ErrorMessage = "Не указано по-батькові")]
        public string secondName { get; set; }

        public string Email { get; set; }
        public string descProfile { get; set; }
    }
}
