﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class Petition
    {
        [Key]
        public int PetitionId { get; set; }
        public string title { get; set; }
        public string text { get; set; }
        public int StatusId { get; set; }
        public string datePublication { get; set; }
        public string timePublication { get; set; }
        public int colSignature { get; set; }
        public int UserId { get; set; }
        public string img { get; set; }
        public Category Category { get; set; }
    }
}
