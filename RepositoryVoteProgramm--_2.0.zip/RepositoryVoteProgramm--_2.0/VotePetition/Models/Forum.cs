﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class Forum
    {
        [Key]
        public int ForumId { get; set; }
        public string title { get; set; }
        public string text { get; set; }
        public int UserId { get; set; }
    }
}
