﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace VotePetition.Models
{
    public class User
    {
        [Key]
        public int? UserId { get; set; }
        public string surname { get; set; }
        public string name { get; set; }
        public string secondName { get; set; }
        public string addres { get; set; }
        public string email { get; set; }
        public string number { get; set; }
        public string password { get; set; }
        public int? roleId { get; set; }
        public string INN { get; set; }
        public string descProfile { get; set; }
        public string img { get; set; }
        public Role Role { get; set; }
    }
}
